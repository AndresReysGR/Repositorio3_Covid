-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 30, 2022 at 12:59 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `covid`
--

-- --------------------------------------------------------

--
-- Table structure for table `capturas_encuesta`
--

CREATE TABLE `capturas_encuesta` (
  `id` int(11) NOT NULL,
  `id_tipo_usuario` int(11) NOT NULL,
  `matricula` varchar(32) DEFAULT NULL,
  `numero_profesor` varchar(32) DEFAULT NULL,
  `numero_empleado` text,
  `nombre` varchar(255) NOT NULL,
  `correo` varchar(128) NOT NULL,
  `contacto_covid` tinyint(1) NOT NULL DEFAULT '0',
  `vacunado` tinyint(1) NOT NULL DEFAULT '1',
  `cadena_qr` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `capturas_encuesta`
--

INSERT INTO `capturas_encuesta` (`id`, `id_tipo_usuario`, `matricula`, `numero_profesor`, `numero_empleado`, `nombre`, `correo`, `contacto_covid`, `vacunado`, `cadena_qr`, `created_at`, `updated_at`) VALUES
(1, 1, '189216', NULL, NULL, 'Pedro Gutierrez', 'perdo@hothot.com', 1, 1, '123456789', '2022-04-30 07:38:09', '2022-04-30 07:38:09'),
(2, 1, '216423', NULL, NULL, 'Pepe Garza', 'doaaaa@a.com', 1, 1, '123456789', '2022-04-30 07:53:03', '2022-04-30 07:53:03'),
(3, 1, '216423', NULL, NULL, 'Pepe Garza', 'doaaaa@a.com', 1, 1, '123456789', '2022-04-30 07:55:35', '2022-04-30 07:55:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `capturas_encuesta`
--
ALTER TABLE `capturas_encuesta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_tipo_usuario` (`id_tipo_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `capturas_encuesta`
--
ALTER TABLE `capturas_encuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `capturas_encuesta`
--
ALTER TABLE `capturas_encuesta`
  ADD CONSTRAINT `capturas_encuesta_ibfk_1` FOREIGN KEY (`id_tipo_usuario`) REFERENCES `tipos_usuario` (`id`);
